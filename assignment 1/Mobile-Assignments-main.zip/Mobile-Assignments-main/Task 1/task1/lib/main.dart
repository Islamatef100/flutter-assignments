import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Scaffold(
      appBar: AppBar(
        title: const Text('First Application'),
        backgroundColor: Colors.green,
      ),
      body: const Center(
        child: Text("Islam Sayed Galal"),
      ),
    ),
  ));
}